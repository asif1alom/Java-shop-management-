# JDBC Swing Shop Manager

A simple Java desktop application built with:

- Swing for the interface
- JDBC for database operations
- MySQL for the database

## Features

- Add a product
- View all products
- Edit a product record
- Delete a product
- Search products by name

## Project Structure

- `src/main/java` contains Java source code
- `pom.xml` configures the Maven desktop application

## How to Run

1. Install Java 11+, Maven, and MySQL.
2. Start MySQL.
3. Create a MySQL database named `jdbc_jframe_db`.
4. Check `src/main/resources/db.properties` for your MySQL settings.
5. Build the project:
   ```bash
   mvn clean package
   ```
6. Run the desktop app:
   ```bash
   mvn exec:java
   ```

## Notes

- The `products` table is created automatically when the app first connects.
- Default connection settings assume MySQL running on `localhost:3306` with user `root` and an empty password.

## Configuration

- `src/main/resources/db.properties` stores database settings.
- Environment variables `DB_URL`, `DB_USER`, and `DB_PASSWORD` can override the file.

## IntelliJ

1. Open the project root in IntelliJ.
2. Import it as a Maven project.
3. Run `com.example.jdbcjframe.ui.ShopManagerApp`.

## UI Flow

- Enter a product name, category, and price.
- Click `Save Product` to add a product.
- Select a row and click `Delete Selected` to remove it.
- Click `Refresh` to reload the table.
