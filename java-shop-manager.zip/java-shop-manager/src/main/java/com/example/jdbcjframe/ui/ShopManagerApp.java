package com.example.jdbcjframe.ui;

import com.example.jdbcjframe.dao.ProductDAO;
import com.example.jdbcjframe.model.Product;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

public class ShopManagerApp extends JFrame {
    private final ProductDAO productDAO = new ProductDAO();
    private final DefaultTableModel tableModel;
    private final JTable productTable;
    private final JTextField nameField;
    private final JTextField categoryField;
    private final JTextField priceField;
    private final JTextField searchField;
    private JButton saveButton;
    private int editingId = -1;

    public ShopManagerApp() {
        super("Shop Manager");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(860, 560);
        setLocationRelativeTo(null);

        JPanel content = new JPanel(new BorderLayout(16, 16));
        content.setBorder(new EmptyBorder(16, 16, 16, 16));
        setContentPane(content);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Add Product"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        nameField = new JTextField(18);
        categoryField = new JTextField(18);
        priceField = new JTextField(18);

        addRow(formPanel, gbc, 0, "Name", nameField);
        addRow(formPanel, gbc, 1, "Category", categoryField);
        addRow(formPanel, gbc, 2, "Price", priceField);

        saveButton = new JButton("Save Product");
        saveButton.addActionListener(e -> saveProduct());
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(12, 8, 8, 8);
        formPanel.add(saveButton, gbc);

        tableModel = new DefaultTableModel(new Object[]{"ID", "Name", "Category", "Price"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        productTable = new JTable(tableModel);
        productTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane tableScrollPane = new JScrollPane(productTable);
        tableScrollPane.setBorder(BorderFactory.createTitledBorder("Saved Products"));

        JPanel actionsPanel = new JPanel();
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadProducts());
        JButton deleteButton = new JButton("Delete Selected");
        deleteButton.addActionListener(e -> deleteSelectedProduct());
        JButton editButton = new JButton("Edit Selected");
        editButton.addActionListener(e -> editSelectedProduct());
        JButton clearFormButton = new JButton("Clear Form");
        clearFormButton.addActionListener(e -> clearForm());
        actionsPanel.add(refreshButton);
        actionsPanel.add(deleteButton);
        actionsPanel.add(editButton);
        actionsPanel.add(clearFormButton);

        JPanel searchPanel = new JPanel();
        searchField = new JTextField(18);
        JButton searchButton = new JButton("Search by Name");
        searchButton.addActionListener(e -> searchProducts());
        JButton clearSearchButton = new JButton("Clear Search");
        clearSearchButton.addActionListener(e -> {
            searchField.setText("");
            loadProducts();
        });
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(clearSearchButton);

        JPanel northPanel = new JPanel(new BorderLayout());
        northPanel.add(searchPanel, BorderLayout.NORTH);
        northPanel.add(formPanel, BorderLayout.CENTER);

        content.add(northPanel, BorderLayout.NORTH);
        content.add(tableScrollPane, BorderLayout.CENTER);
        content.add(actionsPanel, BorderLayout.SOUTH);

        loadProducts();
    }

    private void addRow(JPanel panel, GridBagConstraints gbc, int row, String label, JTextField field) {
        gbc.gridwidth = 1;
        gbc.gridy = row;

        gbc.gridx = 0;
        panel.add(new JLabel(label), gbc);

        gbc.gridx = 1;
        panel.add(field, gbc);
    }

    private void saveProduct() {
        String name = nameField.getText().trim();
        String category = categoryField.getText().trim();
        String priceText = priceField.getText().trim();

        if (name.isEmpty() || category.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
            if (price < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid non-negative price.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            if (editingId > 0) {
                productDAO.update(new Product(editingId, name, category, price));
                JOptionPane.showMessageDialog(this, "Product updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                productDAO.insert(new Product(0, name, category, price));
                JOptionPane.showMessageDialog(this, "Product saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
            clearForm();
            loadProducts();
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedProduct() {
        int selectedRow = productTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a product to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (Integer) tableModel.getValueAt(selectedRow, 0);
        int choice = JOptionPane.showConfirmDialog(this, "Delete the selected product?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            productDAO.delete(id);
            loadProducts();
            JOptionPane.showMessageDialog(this, "Product deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadProducts() {
        try {
            List<Product> products = productDAO.findAll();
            tableModel.setRowCount(0);
            for (Product product : products) {
                tableModel.addRow(new Object[]{
                    product.getId(),
                    product.getName(),
                    product.getCategory(),
                    product.getPrice()
                });
            }
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        nameField.setText("");
        categoryField.setText("");
        priceField.setText("");
        editingId = -1;
        if (saveButton != null) {
            saveButton.setText("Save Product");
        }
    }

    private void editSelectedProduct() {
        int selectedRow = productTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a product to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (Integer) tableModel.getValueAt(selectedRow, 0);
        String name = (String) tableModel.getValueAt(selectedRow, 1);
        String category = (String) tableModel.getValueAt(selectedRow, 2);
        Double price = (Double) tableModel.getValueAt(selectedRow, 3);

        editingId = id;
        nameField.setText(name);
        categoryField.setText(category);
        priceField.setText(String.valueOf(price));
        if (saveButton != null) {
            saveButton.setText("Update Product");
        }
    }

    private void searchProducts() {
        String q = searchField.getText().trim();
        if (q.isEmpty()) {
            loadProducts();
            return;
        }

        try {
            List<Product> products = productDAO.findByName(q);
            tableModel.setRowCount(0);
            for (Product product : products) {
                tableModel.addRow(new Object[]{
                    product.getId(),
                    product.getName(),
                    product.getCategory(),
                    product.getPrice()
                });
            }
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new ShopManagerApp().setVisible(true);
        });
    }
}
